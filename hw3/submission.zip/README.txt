Models are in models.py

Helper functions (trainer/evaluator/predictor) are in helpers.py

See the .ipynb file for examples of usage of our classes (we found
that experimenting in a Jupyter notebook was easier).


