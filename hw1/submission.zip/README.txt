All of our models (and helper classes) can be found in
submission/{helpers.py, models.py}

Some additional functions used in evaluation (and making kaggle
predictions) are in evaluation.py

HW1-models.ipynb and HW1-models-Jesse.ipynb demonstrate usage of our
models.

Ignore submission/main.py (we find it is easier to run our models
through an iPython notebook, when we don't have to load Pytorch/data
each time)
